public class Node{
    
    Node next;
    int elem;
    
    public Node(int elem, Node next){
        this.elem = elem;
        this.next = next;
    }
}
