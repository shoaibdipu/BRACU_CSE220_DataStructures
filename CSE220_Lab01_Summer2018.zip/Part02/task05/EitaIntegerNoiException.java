public class EitaIntegerNoiException extends Exception{
}