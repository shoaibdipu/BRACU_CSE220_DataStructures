/*      
 Task 8
 Create a class called Date that includes three pieces of information as instance 
 variables a month (type int), a day (type int) and a year (type int). 
 Your class should have a constructor that initializes the three instance variables
 and assumes that the values provided are correct. Provide a set and a get method 
 for each instance variable. Provide a method displayDate that displays the month,
 day and year separated by forward slashes (/). 
 Write a test application named DateTest that demonstrates class Date's capabilities.
 */

public class DateTest{
    public static void main(String [] args){
        
        Date d = new Date(10, 07, 2018);
        
        d.displayDate();
    }
}
