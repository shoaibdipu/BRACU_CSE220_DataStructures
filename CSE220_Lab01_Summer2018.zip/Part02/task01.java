/*Task 1
 *Create an array of size 5. Try to store 100 to the index 21 of the array. 
 *It should give you a runtime error. Note the first line of the error that was given.
 *You do not have to handle/catch anything for this task, just note the errors.
 */

import java.util.*;

public class task01{
    public static void main(String [] args){
        
        int a [] = new int [5];
        
        a[21] = 100;
        
    }
}



