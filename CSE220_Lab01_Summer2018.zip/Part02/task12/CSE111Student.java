public class CSE111Student extends Student{
    
    public String msg = "I love Java Programming";
    
    public String shout(){
        return msg;
    }
  
}
