/*Task 2
 *In your main method, try to divide 1 by zero. 
 *Note the first line of the error that was given. 
 *You do not have to handle/catch anything for this task, just note the errors.
 */

import java.util.*;

public class task02{
    public static void main(String [] args){
        
        int c = 42;
        
        int d = 42 / 0;
        
    }
}


